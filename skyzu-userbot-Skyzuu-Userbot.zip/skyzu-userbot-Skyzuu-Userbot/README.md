<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">
   <p align="center">
   𝐒𝐊𝐘𝐙𝐔  -  𝐔𝐒𝐄𝐑𝐁𝐎𝐓​​ 
<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

<p align="center">
    <a href="https://github.com/Skyzu/skyzu-userbot/commits/skyzu-userbot"><img src="https://img.shields.io/github/last-commit/Skyzu/skyzu-userbot?color=ff0000&logo=github&logoColor=ffffff&style=for-the-badge" /></a>
    <a href="https://github.com/Skyzu/Skyzu-userbot"> <img src="https://img.shields.io/github/repo-size/Skyzu/skyzu-userbot?logo=github&style=for-the-badge" /></a>
    <a href="https://pypi.org/project/Telethon/"><img src="https://img.shields.io/pypi/v/telethon?color=important&label=telethon&logo=python&logoColor=brightgreen&style=for-the-badge" /></a>
    <img alt="PYTHON" src="https://img.shields.io/badge/PYTHON-v3.9.6-purple?style=for-the-badge&logo=appveyor"/>
    </p>

<p align="center">
  <img src="https://telegra.ph/file/fd08937c4ae6cb1303731.jpg">
</p>

## <p align="center">DEPLOY TO HEROKU</p>

<p align="center"><a href="https://telegram.dog/XTZ_HerokuBot?start=U2t5enUvc2t5enUtdXNlcmJvdCBTa3l6dXUtVXNlcmJvdA"> <img src="https://img.shields.io/badge/Deploy%20To%20Heroku-blue?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>


## Group Support:

   <a href="https://t.me/skyzusupport"><img src="https://img.shields.io/badge/Group%20Support%3F-yes-green?&style=flat-square?&logo=telegram" width=220px></a></p>


## Stay Support 🚀
❁   [LonamiWebs](https://github.com/LonamiWebs/) and [Telethon](https://github.com/LonamiWebs/Telethon)

##

🔰 **THANKS YOU TO**
*   [Sendi](https://github.com/SendiAp/Rose-Userbot)   Rose-Userbot
*   [Risman](https://github.com/mrismanaziz/Man-Userbot)   Suhu - Userbot
*   [Skyzu](https://github.com/Skyzu/skyzu-userbot)   skyzu-userbot
*   DAN TERIMAKASIH KEPADA USERBOT LAINNYA

