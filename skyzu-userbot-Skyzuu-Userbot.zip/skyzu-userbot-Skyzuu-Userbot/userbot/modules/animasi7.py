import asyncio
from time import sleep

from userbot import CMD_HANDLER as cmd
from userbot import CMD_HELP
from userbot.utils import skyzu_cmd


@skyzu_cmd(pattern="sange$")
async def koc(e):
    if not e.text[0].isalpha() and e.text[0] not in ("/", "#", "@", "!"):
        await e.edit("SAYANGGGGGGGGG 💕")
        sleep(1)
        await e.edit("💝💘💓💗")
        sleep(1)
        await e.edit("💞💕💗💘")
        sleep(1)
        await e.edit("💝💘💓💗")
        sleep(1)
        await e.edit("💞💕💗💘")
        sleep(1)
        await e.edit("💘💞💗💕")
        sleep(1)
        await e.edit("💘💞💕💗")
        sleep(1)
        await e.edit("EMMMMMM🥺🥺🥺")
        sleep(1)
        await e.edit("💝💘💓💗")
        await e.edit("💞💕💗💘")
        await e.edit("💘💞💕💗")
        await e.edit("SAYANG")
        sleep(1)
        await e.edit("AKU 👉👈")
        sleep(1)
        await e.edit("SANGE 👉👈 😘😘")
        sleep(1)
        await e.edit("💘💘💘💘")
        sleep(1)
        await e.edit("SAYANG")
        sleep(1)
        await e.edit("AYO NGEWE🤭🤭")
        sleep(1)
        await e.edit("PLISS🥺🥺")
        sleep(1)
        await e.edit("AKU SANGE😋😋")
        sleep(1)
        await e.edit("I LOVE YOUUUU")
        sleep(1)
        await e.edit("AH AH AH BEIBB")
        sleep(1)
        await e.edit("💦💦💦💦")
        sleep(1)
        await e.edit("OH BABY")
        sleep(1)
        await e.edit("AKU SAYANG KAMU💞")


@skyzu_cmd(pattern="orgil(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit("`ANJING ADA ORANG GILA.....`")
    sleep(1)
    await typew.edit("`ORANG GILAAAAAA!!`")
    sleep(1)
    await typew.edit("`🏃                        🤸`")
    await typew.edit("`🏃                       🤸`")
    await typew.edit("`🏃                      👨‍🦽`")
    await typew.edit("`🏃                     ⛹️`")
    await typew.edit("`🏃   `LARII`          🤾`")
    await typew.edit("`🏃                   🤾`")
    await typew.edit("`🏃                  🤾`")
    await typew.edit("`🏃                 🤾`")
    await typew.edit("`🏃                🤾`")
    await typew.edit("`🏃               🤺`")
    await typew.edit("`🏃              🏊`")
    await typew.edit("`🏃             🏊`")
    await typew.edit("`🏃            🏄`")
    await typew.edit("`🏃           🤾`")
    await typew.edit("`🏃PULUPULU   🧚`")
    await typew.edit("`🏃           ⛹️`")
    await typew.edit("`🏃            ⛹️`")
    await typew.edit("`🏃             🤺`")
    await typew.edit("`🏃              🥴`")
    await typew.edit("`🏃               🏃`")
    await typew.edit("`🏃                🏃`")
    await typew.edit("`🏃                 🤸`")
    await typew.edit("`🏃                  🤸`")
    await typew.edit("`🏃                   🤸`")
    await typew.edit("`🏃                    🤸`")
    await typew.edit("`🏃                     ⛹️`")
    await typew.edit("`🏃  Huh-Huh           🏃`")
    await typew.edit("`🏃                   🤑`")
    await typew.edit("`🏃                  🙈`")
    await typew.edit("`🏃                 ⛹️`")
    await typew.edit("`🏃                🏃`")
    await typew.edit("`🏃               🤴`")
    await typew.edit("`🏃              🐖`")
    await typew.edit("`🏃             🐖`")
    await typew.edit("`🏃            🥴`")
    await typew.edit("`🏃           🥴`")
    await typew.edit("`🏃          🤡`")
    await typew.edit("`🏃         🤭`")
    await typew.edit("`CAPE BANGET ANJING!!!`")
    sleep(1)
    await typew.edit("`🏃       🏃`")
    await typew.edit("`🏃      🤾`")
    await typew.edit("`🏃     🏃`")
    await typew.edit("`🏃    🏃`")
    await typew.edit("`Dahlah Pasrah Aja`")
    sleep(1)
    await typew.edit("`🧎🐖`")
    sleep(2)
    await typew.edit("`-TAMAT-`")


@skyzu_cmd(pattern="mf$")
async def koc(e):
    if not e.text[0].isalpha() and e.text[0] not in ("/", "#", "@", "!"):
        await e.edit("`MAAF GADULU YA`  ")

        for i in animation_ttl:

            await asyncio.sleep(animation_interval)

            await event.edit(animation_chars[i % 11])


@skyzu_cmd(pattern="ass(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit("`Salam dulu biar sopan....`")
    sleep(2)
    await typew.edit("`A`")
    await typew.edit("`As`")
    await typew.edit("`Ass`")
    await typew.edit("`Assa`")
    await typew.edit("`Assal`")
    await typew.edit("`Assala`")
    await typew.edit("`Assalam`")
    await typew.edit("`Assalamu`")
    await typew.edit("`Assalamu'a`")
    await typew.edit("`Assalamu'al`")
    await typew.edit("`Assalamu'ala`")
    await typew.edit("`Assalamu'alai`")
    await typew.edit("`Assalamu'alaik`")
    await typew.edit("`Assalamu'alaiku`")
    await typew.edit("`Assalamu'alaikum`")
    sleep(3)
    await typew.edit("**YANG GA JAWAB, FIX ATHEISS!!**")


# Create by myself @ram-ubot


CMD_HELP.update(
    {
        "animasi7": f"`{cmd}gabut` ; `{cmd}orgil`\
    \nUsage: ntahlah gabut doang.\
    \n\n`{cmd}ass`\
    \nUsage: Salam duls biar sopan."
    }
)

CMD_HELP.update(
    {
        "animasi8": f"`{cmd}cinta`\
    \nUsage: mengirim cintamu ke seseorang.\
    \n\n`{cmd}sange` :\
    \nUsage: cobalah sndiri ngentot."
    }
)
